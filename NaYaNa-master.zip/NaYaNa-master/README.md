# NaYaNa
A phonetic script to make communication easy
